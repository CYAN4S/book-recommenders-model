import flask
import tensorflow as tf

model = None


def handler(request: flask.Request):
    global model

    if model is None:
        model = tf.saved_model.load("./result")
        print("COLD INVOCATION")

    request_json = request.get_json(silent=True)

    if request_json and 'isbn' in request_json:
        print("ISBN:", request_json['isbn'])
        result = model(tf.constant([request_json['isbn']]))
        return {"result": [isbn.decode(encoding='utf-8') for isbn in result[1].numpy()[0]]}
    else:
        print("NO ISBN")
        return {"result": None}

# functions_framework --target=handler
